# ml_api/ml_service.py
import numpy as np
import cv2
import os
import serial
import pickle
import joblib
from django.conf import settings
from tensorflow.keras.models import load_model
from tensorflow.keras.applications.mobilenet import MobileNet
from tensorflow.keras.layers import Flatten, Dense, Input, Concatenate
from tensorflow.keras.models import Model
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import RobustScaler
from sklearn.feature_selection import SelectKBest, f_classif
import pandas as pd
import logging

logger = logging.getLogger(__name__)

class MLService:
    def __init__(self):
        self.emotion_model = None
        self.cvd_model = None
        self.scaler = None
        self.feature_selector = None
        self.sensor_connection = None
        self.load_models()
        self.init_sensor()
    
    def load_models(self):
        """Load all ML models"""
        try:
            # Load emotion detection model
            if os.path.exists(settings.ML_MODEL_PATH):
                self.emotion_model = load_model(settings.ML_MODEL_PATH)
                logger.info("Emotion detection model loaded successfully")
            else:
                self.create_emotion_model()
                logger.info("Created new emotion detection model")
            
            # Load CVD prediction model
            cvd_model_path = os.path.join(settings.BASE_DIR, 'models', 'cvd_model.pkl')
            scaler_path = os.path.join(settings.BASE_DIR, 'models', 'scaler.pkl')
            selector_path = os.path.join(settings.BASE_DIR, 'models', 'feature_selector.pkl')
            
            if os.path.exists(cvd_model_path):
                self.cvd_model = joblib.load(cvd_model_path)
                self.scaler = joblib.load(scaler_path)
                self.feature_selector = joblib.load(selector_path)
                logger.info("CVD prediction model loaded successfully")
            else:
                self.create_cvd_model()
                logger.info("Created new CVD prediction model")
                
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            self.create_emotion_model()
            self.create_cvd_model()
    
    def create_emotion_model(self):
        """Create emotion detection model if it doesn't exist"""
        base_model = MobileNet(input_shape=(224, 224, 3), include_top=False)
        for layer in base_model.layers:
            layer.trainable = False
        
        image_input = base_model.input
        image_features = Flatten()(base_model.output)
        image_features = Dense(128, activation='relu')(image_features)
        
        biometric_input = Input(shape=(6,))
        biometric_features = Dense(32, activation='relu')(biometric_input)
        biometric_features = Dense(16, activation='relu')(biometric_features)
        
        combined = Concatenate()([image_features, biometric_features])
        combined = Dense(64, activation='relu')(combined)
        output = Dense(1, activation='sigmoid')(combined)
        
        self.emotion_model = Model(inputs=[image_input, biometric_input], outputs=output)
        self.emotion_model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    
    def create_cvd_model(self):
        """Create CVD prediction model with sample data structure"""
        # Create a simple model for demonstration
        self.cvd_model = RandomForestClassifier(
            n_estimators=50,
            max_depth=3,
            min_samples_split=10,
            min_samples_leaf=5,
            max_features='sqrt',
            random_state=42,
            class_weight='balanced'
        )
        
        # Create dummy scaler and selector for the expected features
        self.scaler = RobustScaler()
        self.feature_selector = SelectKBest(score_func=f_classif, k=6)
        
        # Fit with dummy data (you should replace this with actual training)
        dummy_data = np.random.rand(100, 6)  # 6 features: HR, BP_sys, BP_dia, O2, RR, Temp
        dummy_labels = np.random.choice([0, 1], 100)
        
        scaled_data = self.scaler.fit_transform(dummy_data)
        selected_data = self.feature_selector.fit_transform(scaled_data, dummy_labels)
        self.cvd_model.fit(selected_data, dummy_labels)
        
        # Save the models
        models_dir = os.path.join(settings.BASE_DIR, 'models')
        os.makedirs(models_dir, exist_ok=True)
        
        joblib.dump(self.cvd_model, os.path.join(models_dir, 'cvd_model.pkl'))
        joblib.dump(self.scaler, os.path.join(models_dir, 'scaler.pkl'))
        joblib.dump(self.feature_selector, os.path.join(models_dir, 'feature_selector.pkl'))
    
    def init_sensor(self):
        """Initialize sensor connection"""
        try:
            self.sensor_connection = serial.Serial(
                settings.SENSOR_PORT, 
                settings.SENSOR_BAUDRATE, 
                timeout=1
            )
            logger.info("Sensor connection established")
        except Exception as e:
            logger.warning(f"Could not connect to sensor: {e}")
            self.sensor_connection = None
    
    def read_sensor_data(self):
        """Read real-time sensor data or return mock data"""
        if not self.sensor_connection:
            # Return mock sensor data with some variation
            return {
                'heart_rate': np.random.normal(75, 10),
                'blood_pressure_systolic': np.random.normal(120, 15),
                'blood_pressure_diastolic': np.random.normal(80, 10),
                'oxygen_saturation': np.random.normal(98, 2),
                'respiratory_rate': np.random.normal(16, 3),
                'temperature': np.random.normal(36.7, 0.5)
            }
        
        try:
            if self.sensor_connection.in_waiting > 0:
                raw_data = self.sensor_connection.readline().decode('utf-8').strip()
                parts = raw_data.split(',')
                if len(parts) >= 7:
                    return {
                        'heart_rate': float(parts[1]),
                        'blood_pressure_systolic': float(parts[2]),
                        'blood_pressure_diastolic': float(parts[3]),
                        'oxygen_saturation': float(parts[4]),
                        'respiratory_rate': float(parts[5]),
                        'temperature': float(parts[6])
                    }
        except Exception as e:
            logger.error(f"Error reading sensor data: {e}")
        
        # Fallback to mock data
        return {
            'heart_rate': 75.0,
            'blood_pressure_systolic': 120.0,
            'blood_pressure_diastolic': 80.0,
            'oxygen_saturation': 98.0,
            'respiratory_rate': 16.0,
            'temperature': 36.7
        }
    
    def preprocess_image(self, image_path):
        """Preprocess image for emotion detection"""
        try:
            img = cv2.imread(image_path)
            img = cv2.resize(img, (224, 224))
            img = img / 255.0
            img = np.expand_dims(img, axis=0)
            return img
        except Exception as e:
            logger.error(f"Error preprocessing image: {e}")
            return None
    
    def predict_emotion(self, image_path, sensor_data=None):
        """Predict emotion state from image and sensor data"""
        try:
            # Preprocess image
            img = self.preprocess_image(image_path)
            if img is None:
                return None
            
            # Get sensor data
            if sensor_data is None:
                sensor_data = self.read_sensor_data()
            
            # Convert sensor data to array
            sensor_array = np.array([[
                sensor_data['heart_rate'],
                sensor_data['blood_pressure_systolic'],
                sensor_data['blood_pressure_diastolic'],
                sensor_data['oxygen_saturation'],
                sensor_data['respiratory_rate'],
                sensor_data['temperature']
            ]])
            
            # Make prediction
            prediction = self.emotion_model.predict([img, sensor_array])
            
            emotion_state = "SERIOUS" if prediction[0][0] > 0.5 else "NOT_SERIOUS"
            confidence = prediction[0][0] if prediction[0][0] > 0.5 else 1 - prediction[0][0]
            
            return {
                'emotion_state': emotion_state,
                'confidence': float(confidence),
                'prediction_score': float(prediction[0][0]),
                'sensor_data': sensor_data
            }
        except Exception as e:
            logger.error(f"Error making emotion prediction: {e}")
            return None
    
    def predict_cvd_risk(self, vital_signs):
        """Predict cardiovascular disease risk from vital signs"""
        try:
            # Convert vital signs to the expected format
            features = np.array([[
                vital_signs.get('heart_rate', 75),
                vital_signs.get('blood_pressure_systolic', 120),
                vital_signs.get('blood_pressure_diastolic', 80),
                vital_signs.get('oxygen_saturation', 98),
                vital_signs.get('respiratory_rate', 16),
                vital_signs.get('temperature', 36.7)
            ]])
            
            # Scale features
            features_scaled = self.scaler.transform(features)
            
            # Select features
            features_selected = self.feature_selector.transform(features_scaled)
            
            # Make prediction
            prediction = self.cvd_model.predict(features_selected)[0]
            prediction_proba = self.cvd_model.predict_proba(features_selected)[0]
            
            # Get risk level
            risk_score = prediction_proba[1]  # Probability of positive class
            
            if risk_score >= 0.7:
                risk_level = "HIGH"
            elif risk_score >= 0.4:
                risk_level = "MEDIUM"
            else:
                risk_level = "LOW"
            
            return {
                'cvd_risk': int(prediction),
                'risk_level': risk_level,
                'risk_score': float(risk_score),
                'confidence': float(max(prediction_proba)),
                'vital_signs': vital_signs
            }
            
        except Exception as e:
            logger.error(f"Error making CVD prediction: {e}")
            return None
    
    def comprehensive_health_assessment(self, image_path=None, vital_signs=None):
        """Perform comprehensive health assessment"""
        results = {}
        
        # Get sensor data if not provided
        if vital_signs is None:
            vital_signs = self.read_sensor_data()
        
        # CVD Risk Assessment
        cvd_result = self.predict_cvd_risk(vital_signs)
        if cvd_result:
            results['cvd_assessment'] = cvd_result
        
        # Emotion Detection (if image provided)
        if image_path:
            emotion_result = self.predict_emotion(image_path, vital_signs)
            if emotion_result:
                results['emotion_assessment'] = emotion_result
        
        # Overall health score
        overall_score = self.calculate_overall_health_score(results)
        results['overall_health_score'] = overall_score
        
        return results
    
    def calculate_overall_health_score(self, assessment_results):
        """Calculate overall health score based on all assessments"""
        try:
            score = 100  # Start with perfect score
            
            # Deduct points based on CVD risk
            if 'cvd_assessment' in assessment_results:
                risk_level = assessment_results['cvd_assessment']['risk_level']
                if risk_level == "HIGH":
                    score -= 30
                elif risk_level == "MEDIUM":
                    score -= 15
            
            # Deduct points based on emotion state
            if 'emotion_assessment' in assessment_results:
                emotion_state = assessment_results['emotion_assessment']['emotion_state']
                if emotion_state == "SERIOUS":
                    score -= 20
            
            # Check vital signs ranges
            if 'cvd_assessment' in assessment_results:
                vitals = assessment_results['cvd_assessment']['vital_signs']
                
                # Heart rate (60-100 normal)
                hr = vitals.get('heart_rate', 75)
                if hr < 60 or hr > 100:
                    score -= 10
                
                # Blood pressure (120/80 normal)
                bp_sys = vitals.get('blood_pressure_systolic', 120)
                bp_dia = vitals.get('blood_pressure_diastolic', 80)
                if bp_sys > 140 or bp_dia > 90:
                    score -= 15
                elif bp_sys > 130 or bp_dia > 85:
                    score -= 8
                
                # Oxygen saturation (>95% normal)
                o2 = vitals.get('oxygen_saturation', 98)
                if o2 < 95:
                    score -= 20
                elif o2 < 98:
                    score -= 5
                
                # Temperature (36.1-37.2°C normal)
                temp = vitals.get('temperature', 36.7)
                if temp < 36 or temp > 38:
                    score -= 10
            
            return max(0, min(100, score))
            
        except Exception as e:
            logger.error(f"Error calculating health score: {e}")
            return 50  # Default score

# Global ML service instance
ml_service = MLService()
