# ml_api/models.py
from django.db import models
from django.contrib.auth.models import User

class Patient(models.Model):
    icustay_id = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=200)
    age = models.IntegerField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=[('M', 'Male'), ('F', 'Female')], null=True, blank=True)
    medical_history = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.icustay_id} - {self.name}"

    @property
    def latest_health_score(self):
        """Get the latest overall health score"""
        latest_cvd = self.cvd_assessments.first()
        latest_emotion = self.predictions.first()
        
        if latest_cvd or latest_emotion:
            # Simple calculation - you can make this more sophisticated
            score = 100
            if latest_cvd and latest_cvd.risk_level == 'HIGH':
                score -= 30
            elif latest_cvd and latest_cvd.risk_level == 'MEDIUM':
                score -= 15
            
            if latest_emotion and latest_emotion.emotion_state == 'SERIOUS':
                score -= 20
            
            return max(0, score)
        return None

class SensorReading(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='sensor_readings')
    heart_rate = models.FloatField()
    blood_pressure_systolic = models.FloatField()
    blood_pressure_diastolic = models.FloatField()
    oxygen_saturation = models.FloatField()
    respiratory_rate = models.FloatField()
    temperature = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.patient.icustay_id} - {self.timestamp}"

    @property
    def is_abnormal(self):
        """Check if any vital signs are outside normal ranges"""
        abnormal_indicators = []
        
        if self.heart_rate < 60 or self.heart_rate > 100:
            abnormal_indicators.append('heart_rate')
        
        if self.blood_pressure_systolic > 140 or self.blood_pressure_diastolic > 90:
            abnormal_indicators.append('blood_pressure')
        
        if self.oxygen_saturation < 95:
            abnormal_indicators.append('oxygen_saturation')
        
        if self.temperature < 36.1 or self.temperature > 37.2:
            abnormal_indicators.append('temperature')
        
        if self.respiratory_rate < 12 or self.respiratory_rate > 20:
            abnormal_indicators.append('respiratory_rate')
        
        return abnormal_indicators

class Prediction(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='predictions')
    sensor_reading = models.ForeignKey(SensorReading, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='patient_images/')
    emotion_state = models.CharField(max_length=20)
    confidence = models.FloatField()
    prediction_score = models.FloatField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.patient.icustay_id} - {self.emotion_state} ({self.confidence:.2f})"

class CVDAssessment(models.Model):
    RISK_LEVELS = [
        ('LOW', 'Low Risk'),
        ('MEDIUM', 'Medium Risk'),
        ('HIGH', 'High Risk')
    ]
    
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='cvd_assessments')
    sensor_reading = models.ForeignKey(SensorReading, on_delete=models.CASCADE)
    cvd_risk = models.IntegerField(help_text="0 = No Risk, 1 = Risk Present")
    risk_level = models.CharField(max_length=10, choices=RISK_LEVELS)
    risk_score = models.FloatField(help_text="Probability score between 0 and 1")
    confidence = models.FloatField(help_text="Model confidence in prediction")
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.patient.icustay_id} - CVD Risk: {self.risk_level} ({self.confidence:.2f})"

class HealthAlert(models.Model):
    ALERT_TYPES = [
        ('CRITICAL_VITALS', 'Critical Vital Signs'),
        ('HIGH_CVD_RISK', 'High CVD Risk'),
        ('SERIOUS_EMOTION', 'Serious Emotional State'),
        ('SENSOR_MALFUNCTION', 'Sensor Malfunction'),
        ('MODEL_ERROR', 'Model Prediction Error')
    ]
    
    SEVERITY_LEVELS = [
        ('LOW', 'Low'),
        ('MEDIUM', 'Medium'),
        ('HIGH', 'High'),
        ('CRITICAL', 'Critical')
    ]
    
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='health_alerts')
    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES)
    severity = models.CharField(max_length=10, choices=SEVERITY_LEVELS)
    message = models.TextField()
    is_resolved = models.BooleanField(default=False)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.patient.icustay_id} - {self.alert_type} ({self.severity})"

class ModelPerformanceMetrics(models.Model):
    MODEL_TYPES = [
        ('EMOTION', 'Emotion Detection'),
        ('CVD', 'CVD Risk Assessment')
    ]
    
    model_type = models.CharField(max_length=10, choices=MODEL_TYPES)
    accuracy = models.FloatField()
    precision = models.FloatField()
    recall = models.FloatField()
    f1_score = models.FloatField()
    total_predictions = models.IntegerField(default=0)
    correct_predictions = models.IntegerField(default=0)
    last_updated = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-last_updated']

    def __str__(self):
        return f"{self.model_type} Model - Accuracy: {self.accuracy:.3f}"
