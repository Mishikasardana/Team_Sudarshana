# ml_api/serializers.py
from rest_framework import serializers
from .models import Patient, SensorReading, Prediction, CVDAssessment, HealthAlert, ModelPerformanceMetrics

class PatientSerializer(serializers.ModelSerializer):
    latest_health_score = serializers.ReadOnlyField()
    total_assessments = serializers.SerializerMethodField()
    latest_vitals = serializers.SerializerMethodField()
    
    class Meta:
        model = Patient
        fields = '__all__'
    
    def get_total_assessments(self, obj):
        return obj.predictions.count() + obj.cvd_assessments.count()
    
    def get_latest_vitals(self, obj):
        latest_reading = obj.sensor_readings.first()
        if latest_reading:
            return SensorReadingSerializer(latest_reading).data
        return None

class SensorReadingSerializer(serializers.ModelSerializer):
    is_abnormal = serializers.ReadOnlyField()
    abnormal_indicators = serializers.SerializerMethodField()
    
    class Meta:
        model = SensorReading
        fields = '__all__'
    
    def get_abnormal_indicators(self, obj):
        return obj.is_abnormal

class PredictionSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.name', read_only=True)
    icustay_id = serializers.CharField(source='patient.icustay_id', read_only=True)
    vital_signs = SensorReadingSerializer(source='sensor_reading', read_only=True)
    
    class Meta:
        model = Prediction
        fields = '__all__'

class CVDAssessmentSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.name', read_only=True)
    icustay_id = serializers.CharField(source='patient.icustay_id', read_only=True)
    vital_signs = SensorReadingSerializer(source='sensor_reading', read_only=True)
    risk_percentage = serializers.SerializerMethodField()
    
    class Meta:
        model = CVDAssessment
        fields = '__all__'
    
    def get_risk_percentage(self, obj):
        return round(obj.risk_score * 100, 2)

class HealthAlertSerializer(serializers.ModelSerializer):
    patient_name = serializers.CharField(source='patient.name', read_only=True)
    icustay_id = serializers.CharField(source='patient.icustay_id', read_only=True)
    days_since_created = serializers.SerializerMethodField()
    
    class Meta:
        model = HealthAlert
        fields = '__all__'
    
    def get_days_since_created(self, obj):
        from django.utils import timezone
        delta = timezone.now() - obj.created_at
        return delta.days

class ModelPerformanceMetricsSerializer(serializers.ModelSerializer):
    accuracy_percentage = serializers.SerializerMethodField()
    
    class Meta:
        model = ModelPerformanceMetrics
        fields = '__all__'
    
    def get_accuracy_percentage(self, obj):
        return round(obj.accuracy * 100, 2)

# Request Serializers
class PredictionRequestSerializer(serializers.Serializer):
    icustay_id = serializers.CharField(max_length=100)
    image = serializers.ImageField()
    heart_rate = serializers.FloatField(required=False)
    blood_pressure_systolic = serializers.FloatField(required=False)
    blood_pressure_diastolic = serializers.FloatField(required=False)
    oxygen_saturation = serializers.FloatField(required=False)
    respiratory_rate = serializers.FloatField(required=False)
    temperature = serializers.FloatField(required=False)

class CVDPredictionRequestSerializer(serializers.Serializer):
    icustay_id = serializers.CharField(max_length=100)
    heart_rate = serializers.FloatField(required=False)
    blood_pressure_systolic = serializers.FloatField(required=False)
    blood_pressure_diastolic = serializers.FloatField(required=False)
    oxygen_saturation = serializers.FloatField(required=False)
    respiratory_rate = serializers.FloatField(required=False)
    temperature = serializers.FloatField(required=False)
    
    def validate(self, data):
        # Ensure at least some vital signs are provided
        vital_fields = ['heart_rate', 'blood_pressure_systolic', 'blood_pressure_diastolic', 
                       'oxygen_saturation', 'respiratory_rate', 'temperature']
        
        provided_vitals = [field for field in vital_fields if data.get(field) is not None]
        
        if len(provided_vitals) < 3:
            raise serializers.ValidationError(
                "At least 3 vital sign measurements are required for CVD assessment"
            )
        
        return data

class ComprehensiveAssessmentRequestSerializer(serializers.Serializer):
    icustay_id = serializers.CharField(max_length=100)
    image = serializers.ImageField(required=False)
    heart_rate = serializers.FloatField(required=False)
    blood_pressure_systolic = serializers.FloatField(required=False)
    blood_pressure_diastolic = serializers.FloatField(required=False)
    oxygen_saturation = serializers.FloatField(required=False)
    respiratory_rate = serializers.FloatField(required=False)
    temperature = serializers.FloatField(required=False)

class VitalSignsBatchSerializer(serializers.Serializer):
    """For batch processing of vital signs data"""
    icustay_id = serializers.CharField(max_length=100)
    readings = serializers.ListField(
        child=serializers.DictField(
            child=serializers.FloatField()
        ),
        min_length=1,
        max_length=100
    )

class AlertCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = HealthAlert
        fields = ['patient', 'alert_type', 'severity', 'message']

class AlertResolveSerializer(serializers.Serializer):
    resolved_by = serializers.CharField(max_length=100)
    resolution_notes = serializers.CharField(max_length=500, required=False)

# Summary Serializers
class PatientSummarySerializer(serializers.ModelSerializer):
    """Lightweight patient summary for dashboards"""
    latest_assessment_date = serializers.SerializerMethodField()
    risk_status = serializers.SerializerMethodField()
    alert_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Patient
        fields = ['icustay_id', 'name', 'age', 'gender', 'latest_assessment_date', 
                 'risk_status', 'alert_count', 'latest_health_score']
    
    def get_latest_assessment_date(self, obj):
        latest_prediction = obj.predictions.first()
        latest_cvd = obj.cvd_assessments.first()
        
        dates = []
        if latest_prediction:
            dates.append(latest_prediction.timestamp)
        if latest_cvd:
            dates.append(latest_cvd.timestamp)
        
        return max(dates) if dates else None
    
    def get_risk_status(self, obj):
        latest_cvd = obj.cvd_assessments.first()
        if latest_cvd:
            return latest_cvd.risk_level
        return 'UNKNOWN'
    
    def get_alert_count(self, obj):
        return obj.health_alerts.filter(is_resolved=False).count()

class HealthTrendSerializer(serializers.Serializer):
    """For trend analysis data"""
    timestamp = serializers.DateTimeField()
    health_score = serializers.FloatField()
    cvd_risk_score = serializers.FloatField(required=False)
    emotion_confidence = serializers.FloatField(required=False)
    vital_signs = SensorReadingSerializer()

class SystemStatsSerializer(serializers.Serializer):
    """System-wide statistics"""
    total_patients = serializers.IntegerField()
    total_assessments_today = serializers.IntegerField()
    high_risk_patients = serializers.IntegerField()
    active_alerts = serializers.IntegerField()
    model_accuracy = serializers.DictField()
    sensor_status = serializers.BooleanField()