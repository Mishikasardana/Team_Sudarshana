# ml_api/urls.py
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# API URL patterns
urlpatterns = [
    # Health check
    path('health/', views.HealthCheckView.as_view(), name='health_check'),
    
    # Patient management
    path('patients/', views.PatientListCreateView.as_view(), name='patient_list_create'),
    path('patients/<str:icustay_id>/', views.PatientDetailView.as_view(), name='patient_detail'),
    path('patients/<str:icustay_id>/dashboard/', views.HealthDashboardView.as_view(), name='health_dashboard'),
    
    # Sensor data
    path('patients/<str:icustay_id>/sensor-data/', views.SensorDataView.as_view(), name='sensor_data'),
    path('sensor/realtime/', views.RealTimeSensorView.as_view(), name='realtime_sensor'),
    path('sensor/batch/', views.BatchSensorDataView.as_view(), name='batch_sensor_data'),
    
    # ML Predictions
    path('predict/emotion/', views.EmotionPredictionView.as_view(), name='emotion_prediction'),
    path('predict/cvd/', views.CVDPredictionView.as_view(), name='cvd_prediction'),
    path('predict/comprehensive/', views.ComprehensiveHealthAssessmentView.as_view(), name='comprehensive_assessment'),
    
    # Prediction history
    path('patients/<str:icustay_id>/predictions/', views.PredictionHistoryView.as_view(), name='prediction_history'),
    path('patients/<str:icustay_id>/cvd-assessments/', views.CVDAssessmentHistoryView.as_view(), name='cvd_assessment_history'),
    
    # Health alerts
    path('patients/<str:icustay_id>/alerts/', views.PatientAlertsView.as_view(), name='patient_alerts'),
    path('alerts/', views.AlertListView.as_view(), name='alert_list'),
    path('alerts/<int:alert_id>/resolve/', views.ResolveAlertView.as_view(), name='resolve_alert'),
    
    # Analytics and reporting
    path('analytics/trends/<str:icustay_id>/', views.HealthTrendsView.as_view(), name='health_trends'),
    path('analytics/system-stats/', views.SystemStatsView.as_view(), name='system_stats'),
    path('analytics/model-performance/', views.ModelPerformanceView.as_view(), name='model_performance'),
    
    # Batch operations
    path('batch/vitals/', views.BatchVitalSignsView.as_view(), name='batch_vitals'),
    path('batch/assessments/', views.BatchAssessmentView.as_view(), name='batch_assessments'),
    
    # Export endpoints
    path('export/patient-data/<str:icustay_id>/', views.ExportPatientDataView.as_view(), name='export_patient_data'),
    path('export/system-report/', views.ExportSystemReportView.as_view(), name='export_system_report'),
    
    # Legacy endpoints (for backward compatibility)
    path('predict/', views.PredictionView.as_view(), name='predict_legacy'),
]

# Additional API documentation endpoints (optional)
api_info_patterns = [
    path('info/endpoints/', views.APIEndpointsView.as_view(), name='api_endpoints'),
    path('info/models/', views.ModelInfoView.as_view(), name='model_info'),
    path('info/vital-signs-ranges/', views.VitalSignsRangesView.as_view(), name='vital_signs_ranges'),
]

urlpatterns += api_info_patterns