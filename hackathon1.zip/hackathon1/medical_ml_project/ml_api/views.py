# ml_api/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import Patient, SensorReading, Prediction, CVDAssessment
from .serializers import *
from .ml_service import ml_service
import numpy as np
import logging

logger = logging.getLogger(__name__)

class PatientListCreateView(APIView):
    def get(self, request):
        patients = Patient.objects.all()
        serializer = PatientSerializer(patients, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = PatientSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class PatientDetailView(APIView):
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        serializer = PatientSerializer(patient)
        return Response(serializer.data)

class SensorDataView(APIView):
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        readings = SensorReading.objects.filter(patient=patient)[:10]
        serializer = SensorReadingSerializer(readings, many=True)
        return Response(serializer.data)
    
    def post(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        data = request.data.copy()
        data['patient'] = patient.id
        
        serializer = SensorReadingSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class RealTimeSensorView(APIView):
    def get(self, request):
        sensor_data = ml_service.read_sensor_data()
        return Response({
            **sensor_data,
            'timestamp': timezone.now()
        })

class EmotionPredictionView(APIView):
    """Original emotion prediction endpoint"""
    parser_classes = (MultiPartParser, FormParser)
    
    def post(self, request):
        serializer = PredictionRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        icustay_id = data['icustay_id']
        image = data['image']
        
        # Get or create patient
        patient, created = Patient.objects.get_or_create(
            icustay_id=icustay_id,
            defaults={'name': f'Patient {icustay_id}'}
        )
        
        # Save uploaded image
        image_path = f"media/patient_images/{image.name}"
        with open(image_path, 'wb+') as destination:
            for chunk in image.chunks():
                destination.write(chunk)
        
        # Prepare sensor data
        sensor_data = None
        if any(key in data for key in ['heart_rate', 'blood_pressure_systolic']):
            sensor_data = {
                'heart_rate': data.get('heart_rate', 70),
                'blood_pressure_systolic': data.get('blood_pressure_systolic', 120),
                'blood_pressure_diastolic': data.get('blood_pressure_diastolic', 80),
                'oxygen_saturation': data.get('oxygen_saturation', 98),
                'respiratory_rate': data.get('respiratory_rate', 16),
                'temperature': data.get('temperature', 36.7)
            }
        
        # Make prediction
        result = ml_service.predict_emotion(image_path, sensor_data)
        
        if result is None:
            return Response(
                {'error': 'Failed to make emotion prediction'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Save sensor reading
        sensor_reading = SensorReading.objects.create(
            patient=patient,
            heart_rate=result['sensor_data']['heart_rate'],
            blood_pressure_systolic=result['sensor_data']['blood_pressure_systolic'],
            blood_pressure_diastolic=result['sensor_data']['blood_pressure_diastolic'],
            oxygen_saturation=result['sensor_data']['oxygen_saturation'],
            respiratory_rate=result['sensor_data']['respiratory_rate'],
            temperature=result['sensor_data']['temperature']
        )
        
        # Save prediction
        prediction = Prediction.objects.create(
            patient=patient,
            sensor_reading=sensor_reading,
            image=image,
            emotion_state=result['emotion_state'],
            confidence=result['confidence'],
            prediction_score=result['prediction_score']
        )

        
        return Response({
            'prediction_id': prediction.id,
            'patient_id': patient.id,
            'icustay_id': icustay_id,
            'emotion_state': result['emotion_state'],
            'confidence': result['confidence'],
            'prediction_score': result['prediction_score'],
            'sensor_data': result['sensor_data'],
            'timestamp': prediction.timestamp
        })

class CVDPredictionView(APIView):
    """New CVD prediction endpoint"""
    def post(self, request):
        serializer = CVDPredictionRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        icustay_id = data['icustay_id']
        
        # Get or create patient
        patient, created = Patient.objects.get_or_create(
            icustay_id=icustay_id,
            defaults={'name': f'Patient {icustay_id}'}
        )
        
        # Prepare vital signs data
        vital_signs = {
            'heart_rate': data.get('heart_rate'),
            'blood_pressure_systolic': data.get('blood_pressure_systolic'),
            'blood_pressure_diastolic': data.get('blood_pressure_diastolic'),
            'oxygen_saturation': data.get('oxygen_saturation'),
            'respiratory_rate': data.get('respiratory_rate'),
            'temperature': data.get('temperature')
        }
        
        # Remove None values
        vital_signs = {k: v for k, v in vital_signs.items() if v is not None}
        
        # Make CVD prediction
        result = ml_service.predict_cvd_risk(vital_signs)
        
        if result is None:
            return Response(
                {'error': 'Failed to make CVD prediction'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Save sensor reading
        sensor_reading = SensorReading.objects.create(
            patient=patient,
            heart_rate=result['vital_signs']['heart_rate'],
            blood_pressure_systolic=result['vital_signs']['blood_pressure_systolic'],
            blood_pressure_diastolic=result['vital_signs']['blood_pressure_diastolic'],
            oxygen_saturation=result['vital_signs']['oxygen_saturation'],
            respiratory_rate=result['vital_signs']['respiratory_rate'],
            temperature=result['vital_signs']['temperature']
        )
        
        # Save CVD assessment
        cvd_assessment = CVDAssessment.objects.create(
            patient=patient,
            sensor_reading=sensor_reading,
            cvd_risk=result['cvd_risk'],
            risk_level=result['risk_level'],
            risk_score=result['risk_score'],
            confidence=result['confidence']
        )
        
        return Response({
            'assessment_id': cvd_assessment.id,
            'patient_id': patient.id,
            'icustay_id': icustay_id,
            'cvd_risk': result['cvd_risk'],
            'risk_level': result['risk_level'],
            'risk_score': result['risk_score'],
            'confidence': result['confidence'],
            'vital_signs': result['vital_signs'],
            'timestamp': cvd_assessment.timestamp
        })

class ComprehensiveHealthAssessmentView(APIView):
    """Comprehensive health assessment combining all predictions"""
    parser_classes = (MultiPartParser, FormParser)
    
    def post(self, request):
        serializer = ComprehensiveAssessmentRequestSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        icustay_id = data['icustay_id']
        image = data.get('image')
        
        # Get or create patient
        patient, created = Patient.objects.get_or_create(
            icustay_id=icustay_id,
            defaults={'name': f'Patient {icustay_id}'}
        )
        
        # Prepare vital signs data
        vital_signs = {
            'heart_rate': data.get('heart_rate'),
            'blood_pressure_systolic': data.get('blood_pressure_systolic'),
            'blood_pressure_diastolic': data.get('blood_pressure_diastolic'),
            'oxygen_saturation': data.get('oxygen_saturation'),
            'respiratory_rate': data.get('respiratory_rate'),
            'temperature': data.get('temperature')
        }
        
        # Remove None values
        vital_signs = {k: v for k, v in vital_signs.items() if v is not None}
        
        # Save uploaded image if provided
        image_path = None
        if image:
            image_path = f"media/patient_images/{image.name}"
            with open(image_path, 'wb+') as destination:
                for chunk in image.chunks():
                    destination.write(chunk)
        
        # Make comprehensive assessment
        result = ml_service.comprehensive_health_assessment(image_path, vital_signs)
        
        if not result:
            return Response(
                {'error': 'Failed to make comprehensive assessment'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
        # Extract vital signs from results
        if 'cvd_assessment' in result:
            vital_signs_data = result['cvd_assessment']['vital_signs']
        else:
            vital_signs_data = ml_service.read_sensor_data()
        
        # Save sensor reading
        sensor_reading = SensorReading.objects.create(
            patient=patient,
            heart_rate=vital_signs_data['heart_rate'],
            blood_pressure_systolic=vital_signs_data['blood_pressure_systolic'],
            blood_pressure_diastolic=vital_signs_data['blood_pressure_diastolic'],
            oxygen_saturation=vital_signs_data['oxygen_saturation'],
            respiratory_rate=vital_signs_data['respiratory_rate'],
            temperature=vital_signs_data['temperature']
        )
        
        response_data = {
            'patient_id': patient.id,
            'icustay_id': icustay_id,
            'overall_health_score': result.get('overall_health_score', 50),
            'timestamp': sensor_reading.timestamp,
            'vital_signs': vital_signs_data
        }
        
        # Save CVD assessment if available
        if 'cvd_assessment' in result:
            cvd_data = result['cvd_assessment']
            cvd_assessment = CVDAssessment.objects.create(
                patient=patient,
                sensor_reading=sensor_reading,
                cvd_risk=cvd_data['cvd_risk'],
                risk_level=cvd_data['risk_level'],
                risk_score=cvd_data['risk_score'],
                confidence=cvd_data['confidence']
            )
            response_data['cvd_assessment'] = {
                'assessment_id': cvd_assessment.id,
                'cvd_risk': cvd_data['cvd_risk'],
                'risk_level': cvd_data['risk_level'],
                'risk_score': cvd_data['risk_score'],
                'confidence': cvd_data['confidence']
            }
        
        # Save emotion prediction if available
        if 'emotion_assessment' in result and image:
            emotion_data = result['emotion_assessment']
            prediction = Prediction.objects.create(
                patient=patient,
                sensor_reading=sensor_reading,
                image=image,
                emotion_state=emotion_data['emotion_state'],
                confidence=emotion_data['confidence'],
                prediction_score=emotion_data['prediction_score']
            )
            response_data['emotion_assessment'] = {
                'prediction_id': prediction.id,
                'emotion_state': emotion_data['emotion_state'],
                'confidence': emotion_data['confidence'],
                'prediction_score': emotion_data['prediction_score']
            }
        
        return Response(response_data)

class PredictionHistoryView(APIView):
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        predictions = Prediction.objects.filter(patient=patient)[:20]
        serializer = PredictionSerializer(predictions, many=True)
        return Response(serializer.data)

class CVDAssessmentHistoryView(APIView):
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        assessments = CVDAssessment.objects.filter(patient=patient)[:20]
        serializer = CVDAssessmentSerializer(assessments, many=True)
        return Response(serializer.data)

class HealthDashboardView(APIView):
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        
        # Get latest assessments
        latest_prediction = Prediction.objects.filter(patient=patient).first()
        latest_cvd = CVDAssessment.objects.filter(patient=patient).first()
        latest_sensor = SensorReading.objects.filter(patient=patient).first()
        
        # Get recent trends (last 10 readings)
        recent_sensors = SensorReading.objects.filter(patient=patient)[:10]
        recent_cvd = CVDAssessment.objects.filter(patient=patient)[:10]
        
        dashboard_data = {
            'patient': PatientSerializer(patient).data,
            'latest_vital_signs': SensorReadingSerializer(latest_sensor).data if latest_sensor else None,
            'latest_emotion_prediction': PredictionSerializer(latest_prediction).data if latest_prediction else None,
            'latest_cvd_assessment': CVDAssessmentSerializer(latest_cvd).data if latest_cvd else None,
            'vital_signs_trend': SensorReadingSerializer(recent_sensors, many=True).data,
            'cvd_risk_trend': CVDAssessmentSerializer(recent_cvd, many=True).data,
            'summary': {
                'total_assessments': patient.predictions.count() + patient.cvd_assessments.count(),
                'total_sensor_readings': patient.sensor_readings.count(),
                'last_updated': latest_sensor.timestamp if latest_sensor else None
            }
        }
        
        return Response(dashboard_data)

class HealthCheckView(APIView):
    def get(self, request):
        return Response({
            'status': 'healthy',
            'emotion_model_loaded': ml_service.emotion_model is not None,
            'cvd_model_loaded': ml_service.cvd_model is not None,
            'sensor_connected': ml_service.sensor_connection is not None,
            'timestamp': timezone.now()
        })

# Legacy endpoint for backward compatibility
class PredictionView(EmotionPredictionView):
    """Legacy prediction endpoint - redirects to emotion prediction"""
    pass

# Additional views to complete the API - add these to your existing ml_api/views.py

# Add these imports to your existing imports
from django.http import HttpResponse
from datetime import timedelta
import json
import csv
import io
from .models import HealthAlert, ModelPerformanceMetrics  # Add these models if not already imported

class BatchSensorDataView(APIView):
    """Handle batch sensor data uploads"""
    def post(self, request):
        serializer = VitalSignsBatchSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        data = serializer.validated_data
        icustay_id = data['icustay_id']
        readings = data['readings']
        
        # Get or create patient
        patient, created = Patient.objects.get_or_create(
            icustay_id=icustay_id,
            defaults={'name': f'Patient {icustay_id}'}
        )
        
        # Create sensor readings
        sensor_readings = []
        for reading in readings:
            sensor_reading = SensorReading.objects.create(
                patient=patient,
                heart_rate=reading.get('heart_rate', 75),
                blood_pressure_systolic=reading.get('blood_pressure_systolic', 120),
                blood_pressure_diastolic=reading.get('blood_pressure_diastolic', 80),
                oxygen_saturation=reading.get('oxygen_saturation', 98),
                respiratory_rate=reading.get('respiratory_rate', 16),
                temperature=reading.get('temperature', 36.7)
            )
            sensor_readings.append(sensor_reading)
        
        return Response({
            'patient_id': patient.id,
            'icustay_id': icustay_id,
            'readings_created': len(sensor_readings),
            'timestamp': timezone.now()
        })

class PatientAlertsView(APIView):
    """Manage patient-specific alerts"""
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        alerts = HealthAlert.objects.filter(patient=patient)
        
        # Filter by status if requested
        status_filter = request.query_params.get('status')
        if status_filter == 'active':
            alerts = alerts.filter(is_resolved=False)
        elif status_filter == 'resolved':
            alerts = alerts.filter(is_resolved=True)
        
        serializer = HealthAlertSerializer(alerts[:20], many=True)
        return Response(serializer.data)
    
    def post(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        data = request.data.copy()
        data['patient'] = patient.id
        
        serializer = AlertCreateSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AlertListView(APIView):
    """System-wide alert management"""
    def get(self, request):
        alerts = HealthAlert.objects.all()
        
        # Filters
        severity = request.query_params.get('severity')
        alert_type = request.query_params.get('type')
        status_filter = request.query_params.get('status', 'active')
        
        if severity:
            alerts = alerts.filter(severity=severity.upper())
        if alert_type:
            alerts = alerts.filter(alert_type=alert_type.upper())
        if status_filter == 'active':
            alerts = alerts.filter(is_resolved=False)
        elif status_filter == 'resolved':
            alerts = alerts.filter(is_resolved=True)
        
        # Pagination
        limit = int(request.query_params.get('limit', 50))
        alerts = alerts[:limit]
        
        serializer = HealthAlertSerializer(alerts, many=True)
        return Response(serializer.data)

class ResolveAlertView(APIView):
    """Resolve a specific alert"""
    def post(self, request, alert_id):
        alert = get_object_or_404(HealthAlert, id=alert_id)
        
        serializer = AlertResolveSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        alert.is_resolved = True
        alert.resolved_at = timezone.now()
        alert.resolved_by = serializer.validated_data['resolved_by']
        alert.save()
        
        return Response({
            'message': 'Alert resolved successfully',
            'alert_id': alert.id,
            'resolved_by': alert.resolved_by,
            'resolved_at': alert.resolved_at
        })

class HealthTrendsView(APIView):
    """Get health trends for a patient"""
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        
        # Get date range
        days = int(request.query_params.get('days', 7))
        end_date = timezone.now()
        start_date = end_date - timedelta(days=days)
        
        # Get sensor readings
        sensor_readings = SensorReading.objects.filter(
            patient=patient,
            timestamp__range=[start_date, end_date]
        ).order_by('timestamp')
        
        # Get CVD assessments
        cvd_assessments = CVDAssessment.objects.filter(
            patient=patient,
            timestamp__range=[start_date, end_date]
        ).order_by('timestamp')
        
        # Get emotion predictions
        emotion_predictions = Prediction.objects.filter(
            patient=patient,
            timestamp__range=[start_date, end_date]
        ).order_by('timestamp')
        
        # Build trend data
        trend_data = []
        for reading in sensor_readings:
            # Find corresponding assessments
            cvd_assessment = cvd_assessments.filter(
                sensor_reading=reading
            ).first()
            
            emotion_prediction = emotion_predictions.filter(
                sensor_reading=reading
            ).first()
            
            trend_point = {
                'timestamp': reading.timestamp,
                'vital_signs': SensorReadingSerializer(reading).data,
                'health_score': patient.latest_health_score or 50
            }
            
            if cvd_assessment:
                trend_point['cvd_risk_score'] = cvd_assessment.risk_score
                trend_point['cvd_risk_level'] = cvd_assessment.risk_level
            
            if emotion_prediction:
                trend_point['emotion_state'] = emotion_prediction.emotion_state
                trend_point['emotion_confidence'] = emotion_prediction.confidence
            
            trend_data.append(trend_point)
        
        return Response({
            'patient_id': patient.id,
            'icustay_id': icustay_id,
            'period': f'{days} days',
            'data_points': len(trend_data),
            'trends': trend_data
        })

class SystemStatsView(APIView):
    """System-wide statistics"""
    def get(self, request):
        # Calculate stats
        total_patients = Patient.objects.count()
        
        # Today's assessments
        today = timezone.now().date()
        today_start = timezone.make_aware(timezone.datetime.combine(today, timezone.datetime.min.time()))
        today_assessments = (
            Prediction.objects.filter(timestamp__gte=today_start).count() +
            CVDAssessment.objects.filter(timestamp__gte=today_start).count()
        )
        
        # High risk patients
        high_risk_patients = Patient.objects.filter(
            cvd_assessments__risk_level='HIGH'
        ).distinct().count()
        
        # Active alerts
        active_alerts = HealthAlert.objects.filter(is_resolved=False).count()
        
        # Model performance
        model_performance = {}
        for model_type in ['EMOTION', 'CVD']:
            latest_metrics = ModelPerformanceMetrics.objects.filter(
                model_type=model_type
            ).first()
            if latest_metrics:
                model_performance[model_type.lower()] = {
                    'accuracy': latest_metrics.accuracy,
                    'precision': latest_metrics.precision,
                    'recall': latest_metrics.recall,
                    'f1_score': latest_metrics.f1_score
                }
        
        return Response({
            'total_patients': total_patients,
            'total_assessments_today': today_assessments,
            'high_risk_patients': high_risk_patients,
            'active_alerts': active_alerts,
            'model_accuracy': model_performance,
            'sensor_status': ml_service.sensor_connection is not None,
            'timestamp': timezone.now()
        })

class ModelPerformanceView(APIView):
    """Model performance metrics"""
    def get(self, request):
        metrics = ModelPerformanceMetrics.objects.all()[:10]
        serializer = ModelPerformanceMetricsSerializer(metrics, many=True)
        return Response(serializer.data)

class BatchVitalSignsView(APIView):
    """Batch process vital signs for multiple patients"""
    def post(self, request):
        # Handle CSV upload
        if 'file' in request.FILES:
            csv_file = request.FILES['file']
            decoded_file = csv_file.read().decode('utf-8')
            csv_data = csv.DictReader(io.StringIO(decoded_file))
            
            results = []
            for row in csv_data:
                icustay_id = row.get('icustay_id')
                if not icustay_id:
                    continue
                
                patient, created = Patient.objects.get_or_create(
                    icustay_id=icustay_id,
                    defaults={'name': f'Patient {icustay_id}'}
                )
                
                sensor_reading = SensorReading.objects.create(
                    patient=patient,
                    heart_rate=float(row.get('heart_rate', 75)),
                    blood_pressure_systolic=float(row.get('blood_pressure_systolic', 120)),
                    blood_pressure_diastolic=float(row.get('blood_pressure_diastolic', 80)),
                    oxygen_saturation=float(row.get('oxygen_saturation', 98)),
                    respiratory_rate=float(row.get('respiratory_rate', 16)),
                    temperature=float(row.get('temperature', 36.7))
                )
                
                results.append({
                    'icustay_id': icustay_id,
                    'patient_id': patient.id,
                    'reading_id': sensor_reading.id,
                    'created': created
                })
            
            return Response({
                'message': 'Batch processing completed',
                'processed_count': len(results),
                'results': results
            })
        
        # Handle JSON batch data
        else:
            serializer = BatchVitalSignsSerializer(data=request.data)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            
            vital_signs_data = serializer.validated_data['vital_signs']
            results = []
            
            for vital_data in vital_signs_data:
                icustay_id = vital_data['icustay_id']
                
                patient, created = Patient.objects.get_or_create(
                    icustay_id=icustay_id,
                    defaults={'name': f'Patient {icustay_id}'}
                )
                
                sensor_reading = SensorReading.objects.create(
                    patient=patient,
                    heart_rate=vital_data.get('heart_rate', 75),
                    blood_pressure_systolic=vital_data.get('blood_pressure_systolic', 120),
                    blood_pressure_diastolic=vital_data.get('blood_pressure_diastolic', 80),
                    oxygen_saturation=vital_data.get('oxygen_saturation', 98),
                    respiratory_rate=vital_data.get('respiratory_rate', 16),
                    temperature=vital_data.get('temperature', 36.7)
                )
                
                results.append({
                    'icustay_id': icustay_id,
                    'patient_id': patient.id,
                    'reading_id': sensor_reading.id,
                    'created': created
                })
            
            return Response({
                'message': 'Batch processing completed',
                'processed_count': len(results),
                'results': results
            })

class ExportDataView(APIView):
    """Export patient data as CSV"""
    def get(self, request):
        # Get parameters
        icustay_id = request.query_params.get('icustay_id')
        days = int(request.query_params.get('days', 30))
        export_type = request.query_params.get('type', 'vital_signs')  # vital_signs, alerts, assessments
        
        # Date range
        end_date = timezone.now()
        start_date = end_date - timedelta(days=days)
        
        response = HttpResponse(content_type='text/csv')
        
        if export_type == 'vital_signs':
            # Export vital signs data
            queryset = SensorReading.objects.filter(
                timestamp__range=[start_date, end_date]
            )
            
            if icustay_id:
                queryset = queryset.filter(patient__icustay_id=icustay_id)
            
            response['Content-Disposition'] = f'attachment; filename="vital_signs_{timezone.now().strftime("%Y%m%d")}.csv"'
            
            writer = csv.writer(response)
            writer.writerow([
                'icustay_id', 'patient_name', 'timestamp', 'heart_rate',
                'blood_pressure_systolic', 'blood_pressure_diastolic',
                'oxygen_saturation', 'respiratory_rate', 'temperature'
            ])
            
            for reading in queryset:
                writer.writerow([
                    reading.patient.icustay_id,
                    reading.patient.name,
                    reading.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    reading.heart_rate,
                    reading.blood_pressure_systolic,
                    reading.blood_pressure_diastolic,
                    reading.oxygen_saturation,
                    reading.respiratory_rate,
                    reading.temperature
                ])
        
        elif export_type == 'alerts':
            # Export alerts data
            queryset = HealthAlert.objects.filter(
                timestamp__range=[start_date, end_date]
            )
            
            if icustay_id:
                queryset = queryset.filter(patient__icustay_id=icustay_id)
            
            response['Content-Disposition'] = f'attachment; filename="alerts_{timezone.now().strftime("%Y%m%d")}.csv"'
            
            writer = csv.writer(response)
            writer.writerow([
                'icustay_id', 'patient_name', 'timestamp', 'alert_type',
                'severity', 'message', 'is_resolved', 'resolved_at', 'resolved_by'
            ])
            
            for alert in queryset:
                writer.writerow([
                    alert.patient.icustay_id,
                    alert.patient.name,
                    alert.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    alert.alert_type,
                    alert.severity,
                    alert.message,
                    alert.is_resolved,
                    alert.resolved_at.strftime('%Y-%m-%d %H:%M:%S') if alert.resolved_at else '',
                    alert.resolved_by or ''
                ])
        
        elif export_type == 'assessments':
            # Export CVD assessments data
            queryset = CVDAssessment.objects.filter(
                timestamp__range=[start_date, end_date]
            )
            
            if icustay_id:
                queryset = queryset.filter(patient__icustay_id=icustay_id)
            
            response['Content-Disposition'] = f'attachment; filename="assessments_{timezone.now().strftime("%Y%m%d")}.csv"'
            
            writer = csv.writer(response)
            writer.writerow([
                'icustay_id', 'patient_name', 'timestamp', 'risk_score',
                'risk_level', 'assessment_notes'
            ])
            
            for assessment in queryset:
                writer.writerow([
                    assessment.patient.icustay_id,
                    assessment.patient.name,
                    assessment.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
                    assessment.risk_score,
                    assessment.risk_level,
                    assessment.assessment_notes or ''
                ])
        
        return response

class HealthSummaryView(APIView):
    """Get comprehensive health summary for a patient"""
    def get(self, request, icustay_id):
        patient = get_object_or_404(Patient, icustay_id=icustay_id)
        
        # Get latest readings
        latest_reading = SensorReading.objects.filter(patient=patient).first()
        latest_cvd = CVDAssessment.objects.filter(patient=patient).first()
        latest_emotion = Prediction.objects.filter(patient=patient).first()
        
        # Get recent alerts (last 24 hours)
        recent_alerts = HealthAlert.objects.filter(
            patient=patient,
            timestamp__gte=timezone.now() - timedelta(hours=24)
        )
        
        # Calculate trends (last 7 days vs previous 7 days)
        now = timezone.now()
        week_ago = now - timedelta(days=7)
        two_weeks_ago = now - timedelta(days=14)
        
        recent_readings = SensorReading.objects.filter(
            patient=patient,
            timestamp__range=[week_ago, now]
        )
        
        previous_readings = SensorReading.objects.filter(
            patient=patient,
            timestamp__range=[two_weeks_ago, week_ago]
        )
        
        # Calculate averages
        def calculate_averages(readings):
            if not readings:
                return {}
            
            count = readings.count()
            return {
                'heart_rate': sum(r.heart_rate for r in readings) / count,
                'blood_pressure_systolic': sum(r.blood_pressure_systolic for r in readings) / count,
                'blood_pressure_diastolic': sum(r.blood_pressure_diastolic for r in readings) / count,
                'oxygen_saturation': sum(r.oxygen_saturation for r in readings) / count,
                'respiratory_rate': sum(r.respiratory_rate for r in readings) / count,
                'temperature': sum(r.temperature for r in readings) / count,
            }
        
        recent_avg = calculate_averages(recent_readings)
        previous_avg = calculate_averages(previous_readings)
        
        # Calculate trends
        trends = {}
        if recent_avg and previous_avg:
            for vital in recent_avg:
                change = recent_avg[vital] - previous_avg[vital]
                trends[vital] = {
                    'change': round(change, 2),
                    'direction': 'up' if change > 0 else 'down' if change < 0 else 'stable'
                }
        
        return Response({
            'patient': {
                'id': patient.id,
                'icustay_id': patient.icustay_id,
                'name': patient.name,
                'health_score': patient.latest_health_score
            },
            'latest_vitals': SensorReadingSerializer(latest_reading).data if latest_reading else None,
            'latest_cvd_assessment': {
                'risk_score': latest_cvd.risk_score,
                'risk_level': latest_cvd.risk_level,
                'timestamp': latest_cvd.timestamp
            } if latest_cvd else None,
            'latest_emotion': {
                'emotion_state': latest_emotion.emotion_state,
                'confidence': latest_emotion.confidence,
                'timestamp': latest_emotion.timestamp
            } if latest_emotion else None,
            'recent_alerts': {
                'count': recent_alerts.count(),
                'critical_count': recent_alerts.filter(severity='CRITICAL').count(),
                'alerts': HealthAlertSerializer(recent_alerts[:5], many=True).data
            },
            'trends': trends,
            'summary_generated_at': timezone.now()
        })